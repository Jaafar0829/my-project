import { Code2, Smartphone, MonitorDot, Paintbrush2 } from "lucide-react";
const SKILLS = [{
  icon: Code2,
  label: "JavaScript"
}, {
  icon: MonitorDot,
  label: "React.js"
}, {
  icon: Smartphone,
  label: "Mobile Apps"
}, {
  icon: Paintbrush2,
  label: "UI/UX Design"
}
// Add more if needed
];
const About = () => <div>
    <h2 className="section-title">About Me</h2>
    <div className="flex flex-col md:flex-row gap-12 items-start">
      <div className="flex-1 mb-4">
        <p className="text-lg text-muted-foreground mb-4">
          Hello! I'm <span className="text-primary font-bold">Mohammed Riza </span>, a passionate <span className="text-accent font-semibold">Web Developer</span> deeply obsessed with building
          visually stunning, high-performance digital experiences. With a keen eye for design and love for frontend technologies, I turn
          ideas into working, impressive web solutions.
        </p>
        <p className="text-lg text-sky-500">
          Let's create something extraordinary together!
        </p>
      </div>
      <div className="flex-1">
        <h3 className="font-title text-xl mb-3 text-primary">Skills & Tools</h3>
        <ul className="flex flex-wrap gap-4">
          {SKILLS.map(({
          icon: Icon,
          label
        }) => <li key={label} className="flex items-center gap-2 bg-card/60 rounded-lg px-3 py-2 shadow border border-border">
              <Icon className="w-6 h-6 text-accent" />
              <span className="text-[1.08rem] font-semibold">{label}</span>
            </li>)}
        </ul>
      </div>
    </div>
  </div>;
export default About;