
import { Globe, Code, Smartphone, Brush } from "lucide-react";

const PROJECTS = [
  {
    title: "Portfolio Website",
    desc: "A stunning, modern, and fully responsive portfolio built with React and Tailwind CSS.",
    url: "#",
    icon: <Brush className="text-accent w-7 h-7" />,
    tags: ["React", "Tailwind", "Responsive"],
  },
  {
    title: "E-commerce Dashboard",
    desc: "Advanced dashboard for shop admins with real-time analytics and beautiful charts.",
    url: "#",
    icon: <Globe className="text-accent w-7 h-7" />,
    tags: ["TypeScript", "Recharts", "Dashboard"],
  },
  {
    title: "Mobile App",
    desc: "Cross-platform mobile app with instant sync and smooth UX.",
    url: "#",
    icon: <Smartphone className="text-accent w-7 h-7" />,
    tags: ["React Native", "SQLite", "Mobile"],
  },
  {
    title: "Code Snippet Library",
    desc: "Personal library of reusable code snippets, searchable and sharable.",
    url: "#",
    icon: <Code className="text-accent w-7 h-7" />,
    tags: ["Next.js", "PRISM", "Sharing"],
  },
];

const Projects = () => (
  <>
    <h2 className="section-title">Projects</h2>
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
      {PROJECTS.map((proj, i) => (
        <a
          href={proj.url}
          className="card group relative p-7 shadow-xl bg-gradient-to-br from-card to-[#191726] hover:from-primary/10 hover:to-accent/5 border border-border animate-fade-in"
          style={{ animationDelay: `${i * 80}ms` }}
          key={proj.title}
          target="_blank" rel="noopener noreferrer"
        >
          <div className="mb-3">{proj.icon}</div>
          <h3 className="font-title text-2xl font-bold mb-1 group-hover:text-primary transition">{proj.title}</h3>
          <p className="text-muted-foreground text-base mb-4 min-h-[48px]">{proj.desc}</p>
          <div className="flex flex-wrap gap-2">
            {proj.tags.map((tag) => (
              <span key={tag} className="text-sm bg-accent/10 text-accent px-3 py-1 rounded-full font-semibold">{tag}</span>
            ))}
          </div>
        </a>
      ))}
    </div>
  </>
);

export default Projects;
