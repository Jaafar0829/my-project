
const Footer = () => (
  <footer className="bg-card/80 border-t border-border mt-10 py-6 w-full text-center text-muted-foreground text-sm select-none">
    &copy; {new Date().getFullYear()} John Doe • Crafted with <span className="text-primary">♥</span>
  </footer>
);

export default Footer;
