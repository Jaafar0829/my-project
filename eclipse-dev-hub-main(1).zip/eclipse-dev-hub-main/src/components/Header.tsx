
import { useState } from "react";

const NAV_LINKS = [
  { title: "Home", href: "#home" },
  { title: "Projects", href: "#projects" },
  { title: "About", href: "#about" },
  { title: "Contact", href: "#contact" },
];

const Header = () => {
  const [active, setActive] = useState("Home");

  return (
    <header className="sticky top-0 w-full bg-background/80 backdrop-blur z-50 border-b border-border">
      <nav className="container flex justify-between items-center h-16">
        <span className="text-2xl font-title text-primary tracking-tight py-1 select-none">WebDev Portfolio</span>
        <ul className="hidden md:flex gap-2 lg:gap-5">
          {NAV_LINKS.map((link) => (
            <li key={link.title}>
              <a
                href={link.href}
                className={`nav-link ${active === link.title ? "text-primary" : ""}`}
                onClick={() => setActive(link.title)}
              >
                {link.title}
              </a>
            </li>
          ))}
        </ul>
        {/* Hamburger for mobile - not interactive in this desktop-first version */}
        <div className="md:hidden">
          <span className="inline-block w-7 h-1 bg-primary rounded mb-1"></span>
          <span className="inline-block w-7 h-1 bg-primary rounded mb-1"></span>
          <span className="inline-block w-7 h-1 bg-primary rounded"></span>
        </div>
      </nav>
    </header>
  );
};

export default Header;
