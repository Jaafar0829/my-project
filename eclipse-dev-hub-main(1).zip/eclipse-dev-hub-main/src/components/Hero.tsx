
import React from "react";

const Hero = () => (
  <section
    id="home"
    className="bg-gradient-to-b from-background to-[#1a1625] border-b border-border w-full py-24 px-4 md:px-0 animate-fade-in"
  >
    <div className="container flex flex-col md:flex-row gap-12 items-center">
      {/* Profile Image in Circle - now positioned above the name on mobile */}
      <div className="w-full flex flex-col items-center md:items-start md:w-auto relative">
        {/* The image circle */}
        <div className="relative z-10 flex justify-center md:block">
          <div
            className="
              w-44 h-44 md:w-56 md:h-56
              rounded-full 
              border-4 border-primary/60
              bg-transparent
              overflow-hidden
              shadow-xl
              flex items-center justify-center
              mb-[-68px] md:mb-0
            "
            style={{
              background: "transparent",
            }}
          >
            <img
              src="/lovable-uploads/fd8a6fdf-02a6-42bf-a004-7ddf2d7bf8c9.png"
              alt="Profile"
              className="object-cover w-full h-full"
              style={{
                minWidth: "100%",
                minHeight: "100%",
                objectPosition: "center",
              }}
            />
          </div>
        </div>
        {/* Name & Tagline */}
        <div className="flex-1 flex flex-col items-center md:items-start text-center md:text-left w-full md:w-auto">
          <div className="pt-16 md:pt-0">
            <h1 className="text-5xl md:text-6xl font-title font-extrabold mb-6 tracking-tighter leading-none animate-fade-in text-sky-500 relative z-0">
              Mohammed
            </h1>
          </div>
          <p
            className="text-xl md:text-2xl text-muted-foreground max-w-xl mb-6 animate-fade-in"
            style={{
              animationDelay: ".1s",
            }}
          >
            Creative <span className="text-accent font-semibold">Web Developer</span> & Problem Solver. Building elegant digital experiences.
          </p>
          <div
            className="flex gap-4 animate-fade-in"
            style={{
              animationDelay: ".2s",
            }}
          >
            <a
              href="#projects"
              className="bg-primary hover:bg-accent text-primary-foreground font-bold rounded-lg px-6 py-3 transition duration-200 shadow-lg focus:ring-2 focus:ring-accent"
            >
              View Projects
            </a>
            <a
              href="#contact"
              className="border border-primary text-primary hover:bg-primary/10 font-bold rounded-lg px-6 py-3 transition duration-200"
            >
              Contact
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>
);

export default Hero;

