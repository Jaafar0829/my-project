
import React, { useState, useRef, useEffect } from "react";
import { Drawer, DrawerContent, DrawerOverlay, DrawerClose } from "@/components/ui/drawer";
import { Bot, MessageCircle } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

type ChatMessage = {
  role: "user" | "bot";
  content: string;
};

const BOT_WELCOME = "Hello! I'm your AI assistant. How can I help you today?";

const Chatbot = () => {
  const [open, setOpen] = useState(false);
  const [history, setHistory] = useState<ChatMessage[]>([
    { role: "bot", content: BOT_WELCOME },
  ]);
  const [input, setInput] = useState("");
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open && chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [open, history]);

  function handleUserSend(e: React.FormEvent) {
    e.preventDefault();
    if (!input.trim()) return;
    const userMsg = { role: "user" as const, content: input.trim() };
    setHistory((prev) => [...prev, userMsg]);
    setInput("");
    // Simulated Bot reply after short delay
    setTimeout(() => {
      setHistory((prev) => [
        ...prev,
        { role: "bot", content: "🤖 (AI coming soon!) Let me know if you need anything!" },
      ]);
    }, 700);
  }

  return (
    <>
      {/* Floating Chat Button */}
      <button
        className="fixed bottom-6 right-6 z-50 bg-primary text-primary-foreground rounded-full p-4 shadow-lg hover:bg-accent transition-colors focus:outline-none"
        aria-label="Open AI Chatbot"
        onClick={() => setOpen(true)}
        style={{ boxShadow: "0 8px 32px 0 rgba(36,26,86,0.25)" }}
      >
        <MessageCircle className="w-7 h-7" />
      </button>

      {/* Chat Drawer */}
      <Drawer open={open} onOpenChange={setOpen}>
        <DrawerContent className="max-w-full w-[95vw] sm:w-[400px] p-0">
          <div className="flex flex-col h-[70vh] bg-background rounded-t-lg border border-border">
            {/* Header */}
            <div className="p-4 border-b border-border flex items-center gap-2 bg-background rounded-t-lg">
              <Bot className="text-accent w-6 h-6" />
              <span className="font-bold text-lg text-primary flex-1">AI Chatbot</span>
              <DrawerClose
                className="rounded-full p-1 hover:bg-muted focus:outline-none"
                aria-label="Close Chat"
              >
                <span className="text-xl">&times;</span>
              </DrawerClose>
            </div>
            {/* Chat Area */}
            <div className="flex-1 overflow-y-auto px-4 py-3 bg-inherit space-y-3 custom-scrollbar">
              {history.map((m, i) => (
                <div
                  key={i}
                  className={cn(
                    "max-w-[83%] px-4 py-2 rounded-2xl text-base",
                    m.role === "user"
                      ? "ml-auto bg-primary/80 text-primary-foreground rounded-br-md"
                      : "mr-auto bg-card border border-border text-foreground rounded-bl-md flex gap-2 items-start"
                  )}
                >
                  {m.role === "bot" && (
                    <Bot className="w-5 h-5 text-accent mt-0.5 flex-shrink-0" />
                  )}
                  <span>{m.content}</span>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>
            {/* Input */}
            <form
              onSubmit={handleUserSend}
              className="border-t border-border p-3 bg-background flex gap-2"
            >
              <Input
                placeholder="Type your question…"
                className="flex-1"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                autoFocus={open}
                aria-label="Chat input"
              />
              <button
                type="submit"
                className="bg-primary px-4 py-2 rounded-lg text-primary-foreground font-bold hover:bg-accent transition"
                disabled={!input.trim()}
              >
                Send
              </button>
            </form>
          </div>
        </DrawerContent>
      </Drawer>
      <style>
        {`
          .custom-scrollbar::-webkit-scrollbar {
            width: 8px;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #423b63;
            border-radius: 8px;
          }
        `}
      </style>
    </>
  );
};

export default Chatbot;
