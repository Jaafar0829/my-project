import { Mail, Github, Linkedin } from "lucide-react";
const SOCIALS = [{
  name: "Email",
  icon: Mail,
  href: "mailto:john.doe@example.com",
  label: "john.doe@example.com"
}, {
  name: "GitHub",
  icon: Github,
  href: "https://github.com/",
  label: "github.com/yourhandle"
}, {
  name: "LinkedIn",
  icon: Linkedin,
  href: "https://linkedin.com/",
  label: "linkedin.com/in/username"
}];
const Contact = () => <div>
    <h2 className="section-title">Contact</h2>
    <div className="flex flex-col md:flex-row gap-12 items-start">
      {/* Form placeholder (not functional for now) */}
      <div className="flex-1 mb-6">
        <form className="bg-card border border-border p-6 md:p-8 shadow max-w-lg w-full rounded-3xl">
          <h3 className="font-title text-lg mb-4">Send a message</h3>
          <input type="text" placeholder="Your name" className="w-full mb-3 px-4 py-3 rounded bg-muted border border-border text-foreground focus:outline-none focus:border-primary transition" disabled />
          <input type="email" placeholder="Your email" className="w-full mb-3 px-4 py-3 rounded bg-muted border border-border text-foreground focus:outline-none focus:border-primary transition" disabled />
          <textarea placeholder="Your message" rows={5} className="w-full mb-3 px-4 py-3 rounded bg-muted border border-border text-foreground focus:outline-none focus:border-primary resize-none transition" disabled />
          <button type="submit" className="w-full py-3 bg-primary text-primary-foreground font-bold rounded-lg shadow transition hover:bg-accent cursor-not-allowed opacity-70" disabled>
            Coming soon!
          </button>
        </form>
      </div>
      {/* Social links */}
      <div className="flex-1 flex flex-col gap-4">
        <h3 className="font-title text-xl mb-3 text-primary">Get in touch</h3>
        <ul className="space-y-3">
          {SOCIALS.map(({
          icon: Icon,
          name,
          href,
          label
        }) => <li key={name}>
              <a href={href} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 group px-3 py-2 rounded-lg hover:bg-primary/10 transition">
                <Icon className="w-6 h-6 text-primary group-hover:text-accent transition" />
                <span className="text-xl text-slate-300">{label}</span>
              </a>
            </li>)}
        </ul>
      </div>
    </div>
  </div>;
export default Contact;