import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Projects from "@/components/Projects";
import About from "@/components/About";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import Chatbot from "@/components/Chatbot";

const Index = () => {
  return (
    <div className="dark bg-background min-h-screen flex flex-col items-stretch">
      <Header />
      <main className="flex-1 w-full px-0">
        <Hero />
        <section id="projects" className="container py-20">
          <Projects />
        </section>
        <section id="about" className="container py-20">
          <About />
        </section>
        <section id="contact" className="container py-20">
          <Contact />
        </section>
      </main>
      <Footer />
      <Chatbot />
    </div>
  );
};

export default Index;
